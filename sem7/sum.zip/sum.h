#ifndef TEST_STUDENTS_CODE_SUM_H
#define TEST_STUDENTS_CODE_SUM_H

#include <cstdint>

int64_t Sum(int x, int y);

#endif  // TEST_STUDENTS_CODE_SUM_H
